const socket = io();
let username = '';

function setUsername() {
    username = document.getElementById('usernameInput').value.trim();
    if (username) {
        socket.emit('setUsername', username);
        document.getElementById('login').style.display = 'none';
        document.getElementById('chat').style.display = 'flex';
    }
}

function sendMessage() {
    const text = document.getElementById('messageInput').value.trim();
    const imageFile = document.getElementById('imageInput').files[0];

    if (text) {
        socket.emit('chatMessage', { type: 'text', content: text });
        document.getElementById('messageInput').value = '';
    }

    if (imageFile) {
        const reader = new FileReader();
        reader.onload = () => {
            socket.emit('chatMessage', { type: 'image', content: reader.result });
        };
        reader.readAsDataURL(imageFile);
        document.getElementById('imageInput').value = '';
    }
}

socket.on('message', data => {
    const messageContainer = document.getElementById('messages');
    const message = document.createElement('div');
    const isMe = data.user === username;

    message.classList.add('message');
    message.classList.add(isMe ? 'me' : 'other');

    let content = '';
    if (data.type === 'text') {
        content = `<span class="sender">${data.user}</span>${data.content}`;
    } else if (data.type === 'image') {
        content = `<span class="sender">${data.user}</span><img src="${data.content}" alt="Image message">`;
    }

    message.innerHTML = content;
    messageContainer.appendChild(message);
    messageContainer.scrollTop = messageContainer.scrollHeight;
});
