const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const users = {};

app.use(express.static('public'));

io.on('connection', socket => {
    socket.on('setUsername', username => {
        users[socket.id] = username;
        socket.broadcast.emit('message', {
            type: 'text',
            user: 'System',
            content: `${username} joined the chat.`
        });
    });

    socket.on('chatMessage', data => {
        const user = users[socket.id];
        if (user && (data.type === 'text' || data.type === 'image')) {
            io.emit('message', { user, ...data });
        }
    });

    socket.on('disconnect', () => {
        const user = users[socket.id];
        if (user) {
            socket.broadcast.emit('message', {
                type: 'text',
                user: 'System',
                content: `${user} left the chat.`
            });
            delete users[socket.id];
        }
    });
});

http.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
